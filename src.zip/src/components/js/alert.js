/*
function submitStock()
{
    const searchBar = document.getElementById("bar");
    const searchValue = searchBar.value.trim();

    
    if (searchBar.value === "") 
    {
        alert("Please enter something in the search bar.");
    }
    else if (!searchValue.startsWith("$")) 
    {
        alert("The stock ticker must start with a '$'.");
    }
    else
    {
        console.log("Good Search!")
    }
   
}
*/

function submitStock() {
    const searchBar = document.getElementById("bar");
    const searchValue = searchBar.value.trim();
  
    if (searchBar.value === "") {
      alert("Please enter something in the search bar.");
      return false;
    } else if (!searchValue.startsWith("$")) {
      alert("The stock ticker must start with a '$'.");
      return false;
    } else {
      console.log("Good Search!");
      return true;
    }
  }