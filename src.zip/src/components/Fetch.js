import './SearchBar2.css';

$(document).ready(function() {
    $('#search-form').submit(function(event) {
      event.preventDefault();
      const stockName = $('#stock-input').val();
      const url = `/api/sentiment-analysis?stock_name=${stockName}`;
  
      fetch(url)
        .then(response => response.json())
        .then(data => {
          const sentimentScore = data.tweets;
          // Do something with the sentiment score
        });
    });
    return (
        <form id="search-form">
            <input id="stock-input" type="text" placeholder="Enter a stock name" />
            <button type="submit" id="click" >Analyze</button>
        </form>
        );  
});