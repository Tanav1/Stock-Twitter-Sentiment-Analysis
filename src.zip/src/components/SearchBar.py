import tweepy
import re
import pandas as pd
from textblob import TextBlob
from flask import Flask, request, jsonify, render_template

app = Flask(__name__)


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/search', methods=['POST'])
def search_tweets():
    query = request.form['query']
    print(query)
    CONSUMER_KEY = "4B5GY48zWTjJAKhjHfUbjhQ0I"
    CONSUMER_SECRET = "L8s5a8UCLcVtX1oI1uJF2XOx4XCCRFr7RJDmxHCCkrHcDGhXIy"
    ACCESS_TOKEN = "2990641845-rFGtRNud780aUwBMudhcQDHMOjLOwasbvRxZhyS"
    ACCESS_TOKEN_SECRET = "SqFMTHD1ZlfqP47n6dHPQCnqZVBoBttZUJKEk7S2txuNv"

    # Authenticate to Twitter
    auth = tweepy.OAuthHandler(consumer_key=CONSUMER_KEY, consumer_secret=CONSUMER_SECRET)
    auth.set_access_token(ACCESS_TOKEN, ACCESS_TOKEN_SECRET)

    # build a api object, and the introduction about the rate limit will be cover in next lab
    api = tweepy.API(auth)
    tweets = []

    # call twitter api to fetch tweets
    fetched_tweets = api.search(q=query, count=1000)
    for tweet in fetched_tweets:
        if tweet.lang == 'en':
            # cleaning the tweets
            tweet = tweet.text
            tweet = tweet.lower()
            tweet = re.sub(r"[^\w$#\s]+", "", tweet)

            # tokenized = tweet.split()

            # getting the sentiment from textblob
            analysis = TextBlob(tweet)
            # Removing Punctuations, Numbers, and Special Characters

            senti = analysis.sentiment.polarity
            # labeling the sentiment
            if senti < 0:
                emotion = "NEG"
            elif senti > 0:
                emotion = "POS"
            else:
                emotion = "NEU"
            # appending all data
            tweets.append((tweet, senti, emotion))
            df= pd.DataFrame(tweets, columns= ['tweets', 'senti', 'emotion'])
            df= df.drop_duplicates()
            keywords = ['community', 'chatroom', 'discord', 'subscriber', 'alert', 'member', 'traders', 'minimize', 'join', 'learn', 'link', 'thanks', 'chat']
            df = df[~df['tweets'].str.lower().str.contains('|'.join(keywords))]
            score = df['senti'].mean()

    


    return render_template('results.html', df=df, query=query, score=score)

    # return jsonify(tweets)



if __name__ == '__main__':
    app.run(debug=True)