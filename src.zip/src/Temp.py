from flask import Flask, request, jsonify
import tweepy
import re
from textblob import TextBlob

app = Flask(__name__)

@app.route('/search', methods=['POST'])
def search():
    query = request.form['query']
    count = request.form.get('count', 10, type=int)

    CONSUMER_KEY = "4B5GY48zWTjJAKhjHfUbjhQ0I"
    CONSUMER_SECRET = "L8s5a8UCLcVtX1oI1uJF2XOx4XCCRFr7RJDmxHCCkrHcDGhXIy"
    ACCESS_TOKEN = "2990641845-rFGtRNud780aUwBMudhcQDHMOjLOwasbvRxZhyS"
    ACCESS_TOKEN_SECRET = "SqFMTHD1ZlfqP47n6dHPQCnqZVBoBttZUJKEk7S2txuNv"

    # Authenticate to Twitter
    auth = tweepy.OAuthHandler(consumer_key=CONSUMER_KEY, consumer_secret=CONSUMER_SECRET)
    auth.set_access_token(ACCESS_TOKEN,ACCESS_TOKEN_SECRET)

    # build a api object, and the introduction about the rate limit will be cover in next lab
    api = tweepy.API(auth)
    tweets = []

    try:
        # call twitter api to fetch tweets 
        fetched_tweets = api.search(q=query, count=count) 
        for tweet in fetched_tweets:
            # cleaning the tweets
            tweet = tweet.text
            tweet = tweet.lower()
            tweet = re.sub(r"[^\w$#\s]+", "", tweet)

            # getting the sentiment from textblob
            analysis = TextBlob(tweet)
            #Removing Punctuations, Numbers, and Special Characters

            senti = analysis.sentiment.polarity
            # labeling the sentiment
            if senti < 0:
                emotion = "NEG"
            elif senti > 0:
                emotion = "POS"
            else:
                emotion = "NEU"
            # appending all data
            tweets.append((tweet, senti, emotion))
    except tweepy.TweepError as e:
        # print error (if any) 
        print("Error : " + str(e))

    return jsonify(tweets)

@app.route('/')
def index():
    return '''
        <html>
            <head>
                <title>Search Tweets</title>
                <style>
                    input[type=text] {
                      width: 100%;
                      padding: 12px 20px;
                      margin: 8px 0;
                      box-sizing: border-box;
                      border: 2px solid #ccc;
                      border-radius: 4px;
                    }

                    input[type=submit] {
                      width: 100%;
                      background-color: #4CAF50;
                      color: white;
                      padding: 14px 20px;
                      margin: 8px 0;
                      border: none;
                      border-radius: 4px;
                      cursor: pointer;
                    }

                    input[type=submit]:hover {
                      background-color: #45a049;
                    }
                </style>
            </head>
            <body>
                <h1>Search Tweets</h1>
                <form onsubmit="searchTweets(event)">
                    <label for="query">Query:</label>
                    <input type="text" id="query" name="query"
                    '''